


import string
import criteria
import time
do_once = 0

def read():
    with open("Binary.txt", "r") as bin:
        while True:
            global do_once
            print (do_once)
            if do_once == 0:
                index = 0
                chunk = ""
                do_once += 1
            Cbin = bin.read()
            Cbin = Cbin.translate({ord(c): None for c in string.whitespace})
            if Cbin.isnumeric():
                for i in range(0, len(Cbin), 8):
                    chunk = Cbin[i:i+8]
                    index += 1
                    criteria.Check(chunk)
                break
            
read()



